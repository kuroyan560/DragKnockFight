#include "Swapchain.h"
#include"DescriptorHeap.h"
void Swapchain::SetMetadata()
{
	struct DisplayChromacities
	{
		float RedX;
		float RedY;
		float GreenX;
		float GreenY;
		float BlueX;
		float BlueY;
		float WhiteX;
		float WhiteY;
	} DisplayChromacityList[] = {
	  { 0.64000f, 0.33000f, 0.30000f, 0.60000f, 0.15000f, 0.06000f, 0.31270f, 0.32900f }, // Rec709 
	  { 0.70800f, 0.29200f, 0.17000f, 0.79700f, 0.13100f, 0.04600f, 0.31270f, 0.32900f }, // Rec2020
	};
	int useIndex = 0;
	if (desc.Format == DXGI_FORMAT_R16G16B16A16_FLOAT)
	{
		useIndex = 1;
	}
	const auto& chroma = DisplayChromacityList[useIndex];
	DXGI_HDR_METADATA_HDR10 HDR10MetaData{};
	HDR10MetaData.RedPrimary[0] = UINT16(chroma.RedX * 50000.0f);
	HDR10MetaData.RedPrimary[1] = UINT16(chroma.RedY * 50000.0f);
	HDR10MetaData.GreenPrimary[0] = UINT16(chroma.GreenX * 50000.0f);
	HDR10MetaData.GreenPrimary[1] = UINT16(chroma.GreenY * 50000.0f);
	HDR10MetaData.BluePrimary[0] = UINT16(chroma.BlueX * 50000.0f);
	HDR10MetaData.BluePrimary[1] = UINT16(chroma.BlueY * 50000.0f);
	HDR10MetaData.WhitePoint[0] = UINT16(chroma.WhiteX * 50000.0f);
	HDR10MetaData.WhitePoint[1] = UINT16(chroma.WhiteY * 50000.0f);
	HDR10MetaData.MaxMasteringLuminance = UINT(1000.0f * 10000.0f);
	HDR10MetaData.MinMasteringLuminance = UINT(0.001f * 10000.0f);
	HDR10MetaData.MaxContentLightLevel = UINT16(2000.0f);
	HDR10MetaData.MaxFrameAverageLightLevel = UINT16(500.0f);
	swapchain->SetHDRMetaData(DXGI_HDR_METADATA_TYPE_HDR10, sizeof(HDR10MetaData), &HDR10MetaData);
}

Swapchain::Swapchain(const ComPtr<ID3D12Device>& Device, const ComPtr<IDXGISwapChain1>& Swapchain, DescriptorHeap_CBV_SRV_UAV& DescHeap_CBV_SRV_UAV, DescriptorHeap_RTV& DescHeapRTV, bool UseHDR, float* ClearValue)
{
	Swapchain.As(&swapchain);	//IDXGISwapChain4 �擾
	swapchain->GetDesc1(&desc);

	//�����_�[�^�[�Q�b�g���\�[�X�ݒ�
	CD3DX12_RESOURCE_DESC resDesc(
		D3D12_RESOURCE_DIMENSION_TEXTURE2D,
		0,
		static_cast<UINT>(desc.Width),
		static_cast<UINT>(desc.Height),
		1,
		1,
		desc.Format,
		1,
		0,
		D3D12_TEXTURE_LAYOUT_UNKNOWN,
		D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET
	);

	images.resize(desc.BufferCount);
	fences.resize(desc.BufferCount);
	fenceValues.resize(desc.BufferCount);
	waitEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	HRESULT hr;
	for (UINT i = 0; i < desc.BufferCount; ++i)
	{
		//�t�F���X�̐���
		hr = Device->CreateFence(
			0, D3D12_FENCE_FLAG_NONE,
			IID_PPV_ARGS(&fences[i]));

		if (FAILED(hr))assert(0);   //CreateFenece���s


		//�o�b�N�o�b�t�@�̎擾
		ComPtr<ID3D12Resource1> buff;
		hr = swapchain->GetBuffer(i, IID_PPV_ARGS(&buff));
		if (FAILED(hr))ASSERT_MSG("�X���b�v�`�F�C���Ńo�b�N�o�b�t�@�̎擾�Ɏ��s\n");

		//�o�b�N�o�b�t�@���ݒ�
		std::wstring name = L"BackBuffer -";
		name += std::to_wstring(i);
		buff->SetName(name.c_str());

		//�V�F�[�_�[���\�[�X�r���[�쐬
		DescHeap_CBV_SRV_UAV.CreateSRV(Device, buff, desc.Format);
		DescHandles srvHandles(DescHeap_CBV_SRV_UAV.GetCpuHandleTail(), DescHeap_CBV_SRV_UAV.GetGpuHandleTail());

		//�����_�[�^�[�Q�b�g�r���[�쐬
		DescHeapRTV.CreateRTV(Device, buff);
		DescHandles rtvHandles(DescHeapRTV.GetCpuHandleTail(), DescHeapRTV.GetGpuHandleTail());


		//�o�b�N�o�b�t�@�f�[�^�̏�����
		images[i] = std::make_shared<RenderTarget>(buff, D3D12_RESOURCE_STATE_PRESENT, srvHandles, rtvHandles, resDesc, ClearValue);
	}

	// �t�H�[�}�b�g�ɉ����ăJ���[�X�y�[�X��ݒ�.
	DXGI_COLOR_SPACE_TYPE colorSpace;
	switch (desc.Format)
	{
	default:
		colorSpace = DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709;
		break;
	case DXGI_FORMAT_R16G16B16A16_FLOAT:
		colorSpace = DXGI_COLOR_SPACE_RGB_FULL_G10_NONE_P709;
		break;
	case DXGI_FORMAT_R10G10B10A2_UNORM:
		colorSpace = DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020;
		break;
	}
	swapchain->SetColorSpace1(colorSpace);

	if (UseHDR)
	{
		SetMetadata();
	}
}

void Swapchain::WaitPreviousFrame(const ComPtr<ID3D12CommandQueue>& CmdQueue, const int& FrameIdx)
{
	//�R�}���h���X�g�̎��s������҂�
	auto fence = fences[FrameIdx];
	auto value = ++fenceValues[FrameIdx];
	CmdQueue->Signal(fence.Get(),value);

	//�R�}���h���X�g�̎��s������҂�
	auto nextIdx = swapchain->GetCurrentBackBufferIndex();
	auto finishValue = fenceValues[nextIdx];
	fence = fences[nextIdx];
	value = fence->GetCompletedValue();

	if (value < finishValue)
	{
		HANDLE event = CreateEvent(nullptr, false, false, nullptr);
		auto hr = fence->SetEventOnCompletion(finishValue, event);
		WaitForSingleObject(event, INFINITE);
		CloseHandle(event);
	}
}
