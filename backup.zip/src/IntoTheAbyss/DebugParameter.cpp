#include "DebugParameter.h"
#include"SelectStage.h"

DebugParameter::DebugParameter()
{
	playerData.push_back(PlayerDebugParameterData(15.0f));
	//�f�t�H���g
	nowData = std::make_shared<PlayerDebugParameterData>(15.0f);

	gaugeData = std::make_shared<GaugeDebugParameterData>();
	loadPresetFlag = true;

	roundData = std::make_shared<RoundParameterData>();

	roundData->roundData.maxTimer = 60.0f;
	roundData->roundData.sizeMaxTimer = 60.0f;
	roundData->readyData.maxTimer = 60.0f;
	roundData->readyData.sizeMaxTimer = 60.0f;
	roundData->fightData.maxTimer = 30.0f;
	roundData->fightData.sizeMaxTimer = 30.0f;
	roundData->numberData.maskMaxTimer = 60.0f;
	roundData->nextNumberData.maskMaxTimer = 60.0f;

	roundParamImguiHandle = DebugImGuiManager::Instance()->Add("RoundParameter");
	bossParamImguiHandle = DebugImGuiManager::Instance()->Add("BossParameter");
	playerParamImguiHandle = DebugImGuiManager::Instance()->Add("PlayerParameter");

	bossStageNum = 0;


	bossDebugData.push_back(BossDebugParameterData());
	bossDebugData.push_back(BossDebugParameterData());
	bossDebugData.push_back(BossDebugParameterData());

	//BossDebugParameterData data;
	//bossDebugData.push_back(data);

}

void DebugParameter::Update()
{
	//�v���Z�b�g�I���̐���-----------------------
	if (playerData.size() < 0)
	{
		selectNum = 0;
	}
	else if (playerData.size() <= selectNum)
	{
		selectNum = playerData.size() - 1;
	}
	//�v���Z�b�g�I���̐���-----------------------


	//�v���Z�b�g�ǂݍ���
	if (loadPresetFlag)
	{
	}
}

void DebugParameter::DrawImGui()
{
	if (DebugImGuiManager::Instance()->DrawFlag(playerParamImguiHandle))
	{
		ImGui::Begin("PlayerParameter");
		ImGui::InputFloat("Vel", &playerData[0].playerSpeed);
		ImGui::InputFloat("Damage", &playerData[0].damage);
		ImGui::End();
	}

	if (DebugImGuiManager::Instance()->DrawFlag(bossParamImguiHandle))
	{
		ImGui::Begin("BossParameter");
		ImGui::InputInt("BossParamData", &bossStageNum);

		if (bossStageNum < 0)
		{
			bossStageNum = 0;
		}
		else if (bossDebugData.size() <= bossStageNum)
		{
			bossStageNum = bossDebugData.size() - 1;
		}
		ImGui::InputFloat("Velocity", &bossDebugData[bossStageNum].vel);
		ImGui::InputInt("SWING_COOL_TIME", &bossDebugData[bossStageNum].coolTime);
		ImGui::InputInt("STAMINA_MAX", &bossDebugData[bossStageNum].staminaMax);
		ImGui::InputInt("STAMINA_DASH", &bossDebugData[bossStageNum].staminaDash);
		ImGui::InputInt("STAMINA_SWING", &bossDebugData[bossStageNum].staminaSwing);
		ImGui::InputFloat("SWING_ANGLE", &bossDebugData[bossStageNum].swingAngle);
		ImGui::InputFloat("SWING_MAX", &bossDebugData[bossStageNum].swingMax);
		ImGui::InputFloat("STAMINA_HEAL_AMOUNT", &bossDebugData[bossStageNum].staminaHealAmount);
		ImGui::InputFloat("DAMAGE", &bossDebugData[bossStageNum].damage);
		ImGui::Checkbox("enableToDashAfterSwingFlag", &bossDebugData[bossStageNum].enableToDashAfterSwingFlag);
		ImGui::End();
	}
}

const BossDebugParameterData &DebugParameter::GetBossData()
{
#ifdef DEBUG
	bossStageNum = SelectStage::Instance()->GetStageNum();
#endif // _DEBUG

	return bossDebugData[bossStageNum];
}
