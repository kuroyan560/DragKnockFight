#include "SceneCange.h"

SceneCange::SceneCange()
{
}

SceneCange::~SceneCange()
{
}

void SceneCange::OnStart()
{
	bool debug = false;
}

bool SceneCange::OnUpdate()
{
	nowTrans = false; return true;
};

void SceneCange::OnDraw()
{
}
