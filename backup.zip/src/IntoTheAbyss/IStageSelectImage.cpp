#include "IStageSelectImage.h"
